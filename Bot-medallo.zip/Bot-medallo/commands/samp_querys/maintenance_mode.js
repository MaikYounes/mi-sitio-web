const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle  } = require('discord.js');
require('dotenv').config();
const mysql = require('mysql2/promise');
const { GetPlayerSkin } = require('../../systems/user_get_skin');

module.exports = {
    name: 'smantenimiento',
    description: 'Realiza una tarea de mantenimiento e inserta en la base de datos.',
    async execute(message) {
        const roleId = '1288636152139612301'; // Reemplaza con el ID del rol necesario
        const Announce_Channel = '1288636153817206853';

        const SkinImage = await GetPlayerSkin(message.author.id);
        if (!message.member.roles.cache.has(roleId)) {
            const embed = new EmbedBuilder()
                .setColor(0xff0000)
                .setAuthor({ 
                    name: `❌Acceso Denegado ${message.member.displayName}`, 
                    iconURL: message.author.displayAvatarURL()
                })
                .setDescription(':levitate:•! Permisos insuficientes')
                .setThumbnail(`${SkinImage}`)
                .setTimestamp()
                .setFooter({ text: `${message.author.tag}`, iconURL: message.guild.iconURL() });
            message.channel.send({ embeds: [embed] }).then(() => message.delete().catch(console.error));
            return;
        }

        try {
            const pool = mysql.createPool({
                host: process.env.DB_HOST,
                user: process.env.DB_USER,
                password: process.env.DB_PASSWORD,
                database: process.env.DB_NAME,
            });

            let connection;
            try {
                connection = await pool.getConnection();
                await connection.query('INSERT INTO discord_tasks (type) VALUES (2)');
            } finally {
                if (connection) {
                    connection.release();
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#00FF00')
                .setAuthor({
                    name: `✅ Tarea de Mantenimiento Ejecutada`,
                    iconURL: message.author.displayAvatarURL()
                })
                .setDescription('La tarea de mantenimiento ha sido **insertada con éxito** en la base de datos.')
                .setTimestamp()
                .setFooter({ text: `${message.author.tag}`, iconURL: message.guild.iconURL() });

            const announce_channel = message.guild.channels.cache.get(Announce_Channel);
            const MaintenanceEmbed = new EmbedBuilder()
                .setColor(0xff0000)
                .setAuthor({
                    name: `🔧·Mantenimiento NexusMobile RolePlay Android📱|💻PC`,
                    iconURL: message.guild.iconURL()
                })
                .setDescription('🔧 **GamaMobile está en mantenimiento.**\n⏳ ¡No te vayas! Volveremos pronto con todo funcionando mejor que nunca. 🙌')
                .setImage('https://media.discordapp.net/attachments/1316753645810745508/1327259003369295892/Picsart_25-01-09_18-46-04-286.jpg?ex=67831285&is=6781c105&hm=af8c7e0f63a2c4e927b10a1b46b9df29e171092ac8c3519156e005db15b62446&=&format=webp&width=1440&height=454')
                .setTimestamp()
                .setFooter({ text: `⚙️·El servidor GamaMobile se encuentra en mantenimiento.`, iconURL: message.guild.iconURL() });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('ip_button')
                        .setLabel('sv.gamamobile.xyz:7777')
                        .setEmoji('🔩')
                        .setStyle(ButtonStyle.Secondary)
                );

            await announce_channel.send({ embeds: [MaintenanceEmbed], components: [row] });
            await announce_channel.send('**:clock1:·¡¡ No te vayas !!, Volvemos en un rato a estar en línea.**');
            await message.channel.send({ embeds: [embed] });
        } catch (err) {
            console.error('Error al ejecutar el comando de mantenimiento:', err);
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000')
                .setAuthor({
                    name: `❌ Error ${message.member.displayName}`,
                    iconURL: message.author.displayAvatarURL()
                })
                .setDescription('Hubo un error al intentar ejecutar la tarea de mantenimiento. Por favor, intenta más tarde.')
                .setTimestamp()
                .setFooter({ text: `${message.author.tag}`, iconURL: message.guild.iconURL() });

            await message.channel.send({ embeds: [errorEmbed] });
        }

        await message.delete().catch(console.error);
    },
};
