const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle  } = require('discord.js');
const { GetPlayerSkin } = require('../../systems/user_get_skin');

module.exports = {
    name: 'am',
    description: 'Aviso mantenimiento finalizado',
    async execute(message, pool) {
        const rolesAllowed = [
            '1252519075352154192'
        ];

        const SkinImage = await GetPlayerSkin(message.author.id);
        if (!message.member.roles.cache.some(role => rolesAllowed.includes(role.id))) {
            const embed = new EmbedBuilder()
                .setColor(0xff0000)
                .setAuthor({ 
                    name: `❌Acceso Denegado ${message.member.displayName}`, 
                    iconURL: message.author.displayAvatarURL()
                })
                .setDescription(':levitate:•! Permisos insuficientes')
                .setThumbnail(`${SkinImage}`)
                .setTimestamp()
                .setFooter({ text: `${message.author.tag}`, iconURL: message.guild.iconURL() });
            message.channel.send({ embeds: [embed] }).then(() => message.delete().catch(console.error));
            return;
        }

        const Announce_Channel = '1288636153817206853';
        const announce_channel = message.guild.channels.cache.get(Announce_Channel);

        const MaintenanceEmbed = new EmbedBuilder()
        .setColor(0x2373ff)
        .setAuthor({
            name: `✅·Abierto GamaMobile RolePlay Android📱|💻PC`,
            iconURL: message.guild.iconURL()
        })
        .setDescription('🎮 **¡NexusMobile está abierto!** 🎉\n✨ Ya puedes entrar y disfrutar del juego. ¡Nos vemos dentro! 🚀')
        .setImage('https://cdn.discordapp.com/attachments/1316753645810745508/1327259003008454696/Picsart_25-01-09_18-54-21-639.jpg?ex=67831285&is=6781c105&hm=56882c27feec79085f547eb17d6dd95d181083337152e5655cc214186432bae3&')
        .setTimestamp()
        .setFooter({ text: `📶·El servidor GamaMobile se encuentra nuevamente en línea.`, iconURL: message.guild.iconURL() });
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ip_button')
                    .setLabel('sv.gamamobile.xyz:7777')
                    .setEmoji('🎮')
                    .setStyle(ButtonStyle.Success)
            );

        await announce_channel.send({ embeds: [MaintenanceEmbed], components: [row] });
        await announce_channel.send('**:joystick:·¿Que esperas para entrar a Jugar?, ¡¡disfruta de lo mejor!!**');

        await message.reply('✅ He avisado la finalizacion de el modo mantenimiento.');
    },
};