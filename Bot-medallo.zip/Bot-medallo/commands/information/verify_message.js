const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { GetPlayerSkin } = require('../../systems/user_get_skin');

module.exports = {
    name: 'sverify',
    description: 'Inicia el proceso de verificación de cuenta de juego a Discord',
    async execute(message) {

        const embed = new EmbedBuilder()
            .setColor(0x2373ff)
            .setAuthor({ 
                name: `🎉·Bienvenido a GamaMobile`, 
                iconURL: message.guild.iconURL()
            })
            .setDescription(`Sigue los siguientes pasos para completar la ✅verificación.\n\n` +
                `1️⃣**·PASO 1:** **👀·**Leer y acepta las <#1288636153267884192> y <#1288636153419006022>.\n` +
                `2️⃣**·PASO 2:** Pulsa en 🛡️ Verificar.\n` +
                `3️⃣**·PASO 3:** Sigue los pasos para 🛡️ Verificar tu cuenta y para **🔓·**desbloquear los canales.\n`)
            .setThumbnail(message.guild.iconURL())
            .setImage('https://cdn.discordapp.com/attachments/1265847206087233599/1292201457160032296/240_sin_titulo_20241005210659.png?ex=67120923&is=6710b7a3&hm=4923cd7fb836edb01c8335289b5d64702cc27d387822e86f071817b87654fadb&')
            .setTimestamp()
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('verify')
                    .setLabel('🛡️ Verificar')
                    .setStyle(ButtonStyle.Primary)
            );

        await message.channel.send({ embeds: [embed], components: [row] });
        await message.delete().catch(console.error);
    },
};
