const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'ip',
    description: 'Envía embed con IP.',
    async execute(message) {
        const embed = new EmbedBuilder()
            .setColor(0x2373ff) // Puedes cambiar el color del embed
            .setAuthor({ 
                name: `🏙️•IP NexusMobile RolePlay`, 
                iconURL: message.author.displayAvatarURL()
              })
            .setDescription(
                `🕴️**•**IP: **sv.gamamobile.xyz**\n🖱️·Puerto: **7777**\n**»** 🖥️ [Jugar](https://discordapp.com/channels/1288636152097669170/1307869602818162728/1308200646385598496) **•** 📱 [Jugar](https://discordapp.com/channels/1288636152097669170/1307869602818162728/1308200650634690593)\n`
            )
            .setThumbnail(message.guild.iconURL())
            .setFooter({ text: `${message.author.tag}`, iconURL: message.guild.iconURL() })
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('ip_button')
                    .setLabel('sv.gamamobile.xyz:7777')
                    .setEmoji('🏙️')
                    .setStyle(ButtonStyle.Primary)
            );

        await message.channel.send({ embeds: [embed], components: [row] });
        await message.delete().catch(console.error);
    },
};
