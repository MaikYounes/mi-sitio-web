module.exports = async (interaction) => {
    if (!interaction.isButton()) return;
    const { customId } = interaction;

    if (customId === 'ip_button') {
        interaction.reply({ content: 'sv.gamamobile.xyz:7777', flags: 64 });
    }
};