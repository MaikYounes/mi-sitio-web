const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        const suggestionsChannelId = '1288636154085769391'; // Reemplaza con el ID de tu canal de sugerencias
        const moderatorRoleId = '1288636152139612301'; // Reemplaza con el ID del rol de fundador

        if (message.channel.id === suggestionsChannelId && !message.member.roles.cache.has(moderatorRoleId) && !message.author.bot) {
            const suggestionEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setAuthor({ name: `📮 Nueva sugerencia de ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
                .setDescription(`**💡 · SUGERENCIA:** ${message.content}\n\n**🔍 · La <#${suggestionsChannelId}> será revisada por la administración.**`)
                .setThumbnail(message.author.displayAvatarURL())
                .setFooter({ text: `${message.author.username}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('acceptSuggestion')
                        .setEmoji('✅')
                        //.setLabel('✔️ · ACEPTAR')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('rejectSuggestion')
                        .setEmoji('⛔')
                        //.setLabel('✖️ · RECHAZAR')
                        .setStyle(ButtonStyle.Danger)
                );

            const sentMessage = await message.channel.send({ embeds: [suggestionEmbed], components: [row] });
            await sentMessage.react('👍');
            await sentMessage.react('🤔');
            await sentMessage.react('👎');
            await message.delete();
        }
    });

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isButton()) return;

        if (interaction.customId !== 'acceptSuggestion' && interaction.customId !== 'rejectSuggestion') return;

        const moderatorRoleId = '1288636152139612301'; // Reemplaza con el ID del rol de moderador

        if (!interaction.member.roles.cache.has(moderatorRoleId)) {
            return interaction.reply({ content: '❌· No tienes permiso para realizar esta acción.', ephemeral: true });
        }

        const embed = interaction.message.embeds[0];

        if (interaction.customId === 'acceptSuggestion') {
            const acceptEmbed = EmbedBuilder.from(embed)
                .setColor('#00FF00')
                .setDescription(embed.description + `\n\n**💡 · La sugerencia ha sido ☑️__aceptada__ por ${interaction.member}.**`);

            await interaction.update({ embeds: [acceptEmbed], components: [] });
        } else if (interaction.customId === 'rejectSuggestion') {
            const rejectEmbed = EmbedBuilder.from(embed)
                .setColor('#FF0000')
                .setDescription(embed.description + `\n\n**💡 · La sugerencia ha sido ❌__rechazada__ por ${interaction.member}.**`);

            await interaction.update({ embeds: [rejectEmbed], components: [] });
        }
    });
};
